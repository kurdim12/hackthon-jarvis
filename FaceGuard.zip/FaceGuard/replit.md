# AI Security Platform

## Overview

This is an integrated AI security platform that combines face recognition authentication with a J.A.R.V.I.S. multi-agent AI assistant system. The application serves as a secure gateway where users must authenticate via facial recognition before accessing advanced AI capabilities. The system addresses both security and AI assistance in one cohesive platform, featuring a professional Flask web application with Bootstrap UI, face recognition using OpenCV, Excel-based user management, and an intelligent conversation interface with OpenAI integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Bootstrap 5.3.0 with custom CSS styling
- **Template Engine**: Jinja2 with Flask's render_template
- **UI Components**: Responsive design with card-based layouts, drag-and-drop interfaces, and real-time chat functionality
- **JavaScript**: Vanilla JavaScript for dynamic interactions, voice synthesis, and AJAX communication
- **Styling**: Custom CSS with gradient backgrounds, hover effects, and responsive design patterns

### Backend Architecture
- **Framework**: Flask with session-based authentication
- **Security Model**: Rate limiting for authentication attempts, secure session configuration, and IP-based monitoring
- **Authentication Flow**: Three-tier system (Access Granted, Access Denied, Face Not Found)
- **Face Recognition**: OpenCV-based implementation using Haar Cascades as an alternative to face_recognition library
- **AI Integration**: OpenAI GPT-5 integration with multi-agent capabilities and tool orchestration

### Data Storage Solutions
- **User Database**: Excel-based user permissions system with pandas integration
- **Session Storage**: Flask sessions for authentication state management
- **Logging System**: JSON-based audit logging for authentication attempts and security monitoring
- **Database Preparation**: SQLAlchemy configuration ready for future database integration

### Authentication and Authorization
- **Face Recognition System**: Custom OpenCV implementation with confidence scoring
- **User Management**: Excel-based permissions with user_id, name, access_level, department, and active status
- **Rate Limiting**: Deque-based tracking of authentication attempts with 15-minute windows
- **Security Logging**: Comprehensive audit trail with timestamps, IP addresses, and confidence scores
- **Session Management**: Secure cookie configuration with HttpOnly and SameSite attributes

### AI Agent Architecture
- **J.A.R.V.I.S. Core**: Multi-agent reasoning engine with conversation history and context awareness
- **Tool Integration**: Modular tool system supporting weather API, calculator, time functions, and help system
- **Conversation Management**: Persistent chat history with timestamp tracking and user input processing
- **Voice Synthesis**: Browser-based speech synthesis for audio responses
- **Task Decomposition**: Ability to break complex requests into sequential steps

## External Dependencies

### Core Framework Dependencies
- **Flask**: Web application framework with session management and template rendering
- **SQLAlchemy**: Database ORM with Flask-SQLAlchemy integration (prepared for future use)
- **Pandas**: Excel file processing and data manipulation for user management
- **OpenCV**: Computer vision library for face detection and recognition processing

### AI and Machine Learning
- **OpenAI API**: GPT-5 integration for intelligent conversation and multi-agent capabilities
- **OpenCV Haar Cascades**: Pre-trained face detection models for recognition system

### Frontend Libraries
- **Bootstrap 5.3.0**: CSS framework for responsive design and UI components
- **Font Awesome 6.4.0**: Icon library for consistent visual elements
- **Web Speech API**: Browser-native speech synthesis for voice output

### Security and Monitoring
- **Collections**: Python defaultdict and deque for rate limiting implementation
- **Datetime**: Timestamp management for authentication logging and rate limiting
- **Secrets**: Secure random key generation for development environments
- **JSON**: Audit log storage and configuration management

### File Processing
- **Pathlib**: Modern file path handling for data management
- **OS**: Environment variable access for configuration and security keys
- **Logging**: Application logging and debugging capabilities

### Development and Deployment
- **Environment Variables**: FLASK_SECRET_KEY for production security, DATABASE_URL for database configuration, OPENAI_API_KEY for AI integration
- **Static Assets**: CSS and JavaScript files served through Flask's static file handling
- **Template System**: Jinja2 templates with inheritance and block-based layouts