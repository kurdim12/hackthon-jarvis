"""
Real Face Recognition System using actual celebrity dataset
Uses the downloaded photos to create real face encodings and authentication
"""

import face_recognition
import numpy as np
import pandas as pd
from pathlib import Path
import pickle
import json
from datetime import datetime
import os
from collections import defaultdict
from io import BytesIO

class RealFaceRecognitionSystem:
    # Class-level model cache for performance
    _cached_model = None
    _model_loaded = False
    _model_load_time = None
    
    def __init__(self):
        self.dataset_path = Path("dataset")
        self.models_path = Path("models")
        self.models_path.mkdir(exist_ok=True)
        
        # Real celebrity database based on downloaded photos
        self.celebrity_users = {
            "Adriana Lima": {"user_id": 1, "access_level": "user", "department": "Celebrity", "active": True},
            "Alexandra Daddario": {"user_id": 2, "access_level": "user", "department": "Celebrity", "active": True},
            "Alex Lawther": {"user_id": 3, "access_level": "user", "department": "Celebrity", "active": True},
            "Alvaro Morte": {"user_id": 4, "access_level": "admin", "department": "Celebrity", "active": True}
        }
        
        # Use cached model if available
        if RealFaceRecognitionSystem._model_loaded and RealFaceRecognitionSystem._cached_model:
            cached_data = RealFaceRecognitionSystem._cached_model
            self.face_encodings = cached_data['face_encodings']
            self.face_names = cached_data['face_names']
            self.celebrity_users.update(cached_data.get('celebrity_users', {}))
            self.trained = True
            print(f"✅ Using cached model with {len(self.face_names)} celebrities")
        else:
            self.face_encodings = {}
            self.face_names = []
            self.trained = False
            # Load model in background for future instances
            self._load_model_with_cache()
        
    def discover_photos(self):
        """Discover all celebrity photos in the dataset"""
        photo_files = []
        
        for folder in self.dataset_path.glob("pins_*"):
            if folder.is_dir():
                celebrity_name = folder.name.replace("pins_", "").replace(" ", " ")
                
                for photo in folder.glob("*.jpg"):
                    photo_files.append({
                        'path': photo,
                        'celebrity': celebrity_name,
                        'filename': photo.name
                    })
        
        print(f"📸 Discovered {len(photo_files)} celebrity photos")
        
        # Group by celebrity
        by_celebrity = defaultdict(list)
        for photo in photo_files:
            by_celebrity[photo['celebrity']].append(photo)
        
        for celebrity, photos in by_celebrity.items():
            print(f"  • {celebrity}: {len(photos)} photos")
        
        return photo_files
    
    def extract_face_encodings(self, photo_files):
        """Extract face encodings from all photos"""
        print("🔍 Extracting face encodings from real celebrity photos...")
        
        encodings_by_celebrity = defaultdict(list)
        successful_extractions = 0
        failed_extractions = 0
        
        for i, photo_info in enumerate(photo_files):
            try:
                # Load image
                image = face_recognition.load_image_file(str(photo_info['path']))
                
                # Get face encodings
                face_encodings = face_recognition.face_encodings(image)
                
                if len(face_encodings) == 1:
                    # Single face found - perfect!
                    encodings_by_celebrity[photo_info['celebrity']].append(face_encodings[0])
                    successful_extractions += 1
                elif len(face_encodings) > 1:
                    # Multiple faces - use the first one
                    encodings_by_celebrity[photo_info['celebrity']].append(face_encodings[0])
                    successful_extractions += 1
                else:
                    # No faces found
                    failed_extractions += 1
                    print(f"⚠️ No face found in {photo_info['filename']}")
                
                if (i + 1) % 10 == 0:
                    print(f"  Processed {i + 1}/{len(photo_files)} photos...")
                    
            except Exception as e:
                failed_extractions += 1
                print(f"❌ Error processing {photo_info['filename']}: {e}")
        
        print(f"✅ Face encoding extraction complete!")
        print(f"  • Successful: {successful_extractions}")
        print(f"  • Failed: {failed_extractions}")
        
        return encodings_by_celebrity
    
    def create_average_encodings(self, encodings_by_celebrity):
        """Create average face encodings for each celebrity"""
        print("📊 Creating average face encodings for each celebrity...")
        
        average_encodings = {}
        
        for celebrity, encodings in encodings_by_celebrity.items():
            if len(encodings) > 0:
                # Calculate average encoding
                avg_encoding = np.mean(encodings, axis=0)
                average_encodings[celebrity] = avg_encoding
                print(f"  • {celebrity}: {len(encodings)} photos → 1 average encoding")
        
        return average_encodings
    
    def train_model(self):
        """Train the face recognition model on real celebrity photos"""
        print("🎯 Training face recognition model on real celebrity dataset...")
        
        # Discover photos
        photo_files = self.discover_photos()
        
        if not photo_files:
            print("❌ No photos found in dataset!")
            return False
        
        # Extract face encodings
        encodings_by_celebrity = self.extract_face_encodings(photo_files)
        
        if not encodings_by_celebrity:
            print("❌ No face encodings extracted!")
            return False
        
        # Create average encodings
        self.face_encodings = self.create_average_encodings(encodings_by_celebrity)
        self.face_names = list(self.face_encodings.keys())
        
        # Save the trained model
        model_data = {
            'face_encodings': self.face_encodings,
            'face_names': self.face_names,
            'celebrity_users': self.celebrity_users,
            'trained_on': datetime.now().isoformat()
        }
        
        model_file = self.models_path / "celebrity_face_model.pkl"
        with open(model_file, 'wb') as f:
            pickle.dump(model_data, f)
        
        # Update class-level cache
        RealFaceRecognitionSystem._cached_model = model_data
        RealFaceRecognitionSystem._model_loaded = True
        RealFaceRecognitionSystem._model_load_time = datetime.now()
        
        self.trained = True
        print(f"🎉 Model trained successfully with {len(self.face_names)} celebrities!")
        print(f"📁 Model saved to: {model_file}")
        
        return True
    
    def _load_model_with_cache(self):
        """Load model with class-level caching for performance"""
        # Check if model is already cached
        if RealFaceRecognitionSystem._model_loaded:
            return True
            
        model_file = self.models_path / "celebrity_face_model.pkl"
        
        if not model_file.exists():
            print("⚠️ No trained model found. Training new model...")
            success = self.train_model()
            if success:
                RealFaceRecognitionSystem._model_loaded = True
                RealFaceRecognitionSystem._model_load_time = datetime.now()
            return success
        
        try:
            with open(model_file, 'rb') as f:
                model_data = pickle.load(f)
            
            # Cache the model data at class level
            RealFaceRecognitionSystem._cached_model = model_data
            RealFaceRecognitionSystem._model_loaded = True
            RealFaceRecognitionSystem._model_load_time = datetime.now()
            
            # Set instance variables
            self.face_encodings = model_data['face_encodings']
            self.face_names = model_data['face_names']
            self.celebrity_users.update(model_data.get('celebrity_users', {}))
            self.trained = True
            
            print(f"✅ Loaded and cached model with {len(self.face_names)} celebrities")
            return True
            
        except Exception as e:
            print(f"❌ Error loading model: {e}")
            success = self.train_model()
            if success:
                RealFaceRecognitionSystem._model_loaded = True
                RealFaceRecognitionSystem._model_load_time = datetime.now()
            return success
    
    def load_model(self):
        """Load a pre-trained face recognition model (compatibility method)"""
        return self._load_model_with_cache()
    
    def authenticate_face(self, image_data, ip_address="unknown"):
        """Authenticate a face using real face recognition with logging"""
        try:
            if not self.trained:
                if not self._load_model_with_cache():
                    return False, None, 0.0, "Face recognition model not available"
            
            # Decode uploaded image using face_recognition library
            image_stream = BytesIO(image_data)
            try:
                rgb_image = face_recognition.load_image_file(image_stream)
            except Exception:
                return False, None, 0.0, "Invalid image format"
            
            # Get face encodings from uploaded image
            face_encodings = face_recognition.face_encodings(rgb_image)
            
            if len(face_encodings) == 0:
                return False, None, 0.0, "No face detected in uploaded image"
            
            if len(face_encodings) > 1:
                return False, None, 0.0, "Multiple faces detected - please use image with single face"
            
            # Compare with known celebrity faces
            uploaded_encoding = face_encodings[0]
            
            best_match = None
            best_confidence = 0.0
            
            for celebrity_name, known_encoding in self.face_encodings.items():
                # Calculate face distance (lower is better)
                face_distance = face_recognition.face_distance([known_encoding], uploaded_encoding)[0]
                
                # Convert to confidence score (higher is better)
                confidence = 1 - face_distance
                
                if confidence > best_confidence:
                    best_confidence = confidence
                    best_match = celebrity_name
            
            # DEMO MODE: Very lenient threshold for easy access
            threshold = 0.1
            
            if best_confidence > threshold:
                # Get user info for the matched celebrity
                user_info = self.celebrity_users.get(best_match, {
                    "user_id": 999,
                    "access_level": "user",
                    "department": "Unknown",
                    "active": True
                })
                user_info['name'] = best_match
                
                # Log successful authentication
                self.log_authentication(True, user_info, best_confidence, ip_address, f"Recognized as {best_match}")
                return True, user_info, best_confidence, f"Recognized as {best_match}"
            else:
                # Log failed authentication
                self.log_authentication(False, None, best_confidence, ip_address, f"Face not recognized (best match: {best_match})")
                return False, None, best_confidence, f"Face not recognized (best match: {best_match} with {best_confidence:.2f} confidence)"
                
        except Exception as e:
            print(f"Authentication error: {e}")
            # Log error
            self.log_authentication(False, None, 0.0, ip_address, f"Authentication system error: {str(e)}")
            return False, None, 0.0, f"Authentication system error: {str(e)}"
    
    def log_authentication(self, success, user_info, confidence, ip_address, message):
        """Log authentication attempt for admin dashboard"""
        try:
            # Ensure logs directory exists
            logs_dir = Path("logs")
            logs_dir.mkdir(exist_ok=True)
            
            log_file = logs_dir / "auth_log.json"
            
            # Create new log entry
            log_entry = {
                "timestamp": datetime.now().isoformat(),
                "user_id": user_info.get('user_id') if user_info else None,
                "user_name": user_info.get('name') if user_info else "Unknown",
                "success": success,
                "confidence": confidence,
                "ip_address": ip_address,
                "message": message
            }
            
            # Read existing logs or create empty list
            existing_logs = []
            if log_file.exists():
                try:
                    with open(log_file, 'r') as f:
                        existing_logs = json.load(f)
                except:
                    existing_logs = []
            
            # Add new entry and keep last 1000 entries
            existing_logs.append(log_entry)
            existing_logs = existing_logs[-1000:]  # Keep last 1000 entries
            
            # Write back to file
            with open(log_file, 'w') as f:
                json.dump(existing_logs, f, indent=2)
                
        except Exception as e:
            print(f"⚠️ Logging error: {e}")
    
    def get_authentication_stats(self):
        """Get authentication statistics from log file"""
        try:
            log_file = Path("logs/auth_log.json")
            
            if not log_file.exists():
                return {
                    'total_attempts': 0,
                    'successful_logins': 0,
                    'failed_attempts': 0,
                    'unique_users': len(self.celebrity_users)
                }
            
            # Read authentication logs
            with open(log_file, 'r') as f:
                logs = json.load(f)
            
            # Calculate statistics
            total_attempts = len(logs)
            successful_logins = sum(1 for log in logs if log['success'])
            failed_attempts = total_attempts - successful_logins
            unique_users = len(set(log['user_name'] for log in logs if log['success'] and log['user_name'] != 'Unknown'))
            
            return {
                'total_attempts': total_attempts,
                'successful_logins': successful_logins,
                'failed_attempts': failed_attempts,
                'unique_users': max(unique_users, len(self.celebrity_users))  # At least the known celebrities
            }
            
        except Exception as e:
            print(f"⚠️ Stats error: {e}")
            return {
                'total_attempts': 0,
                'successful_logins': 0,
                'failed_attempts': 0,
                'unique_users': len(self.celebrity_users)
            }

if __name__ == "__main__":
    print("🎬 Real Celebrity Face Recognition System")
    
    system = RealFaceRecognitionSystem()
    
    if system.train_model():
        print("✅ System ready for celebrity face authentication!")
    else:
        print("❌ Failed to train system")