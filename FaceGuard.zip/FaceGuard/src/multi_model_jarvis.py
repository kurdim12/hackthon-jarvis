"""
Multi-Model J.A.R.V.I.S. System
Supports OpenAI, Anthropic Claude, and Google Gemini
"""

import os
import json
from datetime import datetime
from typing import Dict, List, Optional, Any

class MultiModelJarvis:
    def __init__(self):
        self.available_models = {}
        self.current_model = "openai"  # Default to OpenAI
        self.conversation_history = []
        
        # Initialize available models
        self._initialize_models()
        
    def _initialize_models(self):
        """Initialize all available AI models"""
        
        # OpenAI GPT (already configured)
        if os.environ.get('OPENAI_API_KEY'):
            try:
                import openai
                self.available_models['openai'] = {
                    'name': 'OpenAI GPT-4',
                    'client': openai.OpenAI(api_key=os.environ.get('OPENAI_API_KEY')),
                    'status': 'available',
                    'capabilities': ['text', 'multimodal', 'tools']
                }
                print("✅ OpenAI GPT-4 initialized")
            except Exception as e:
                print(f"⚠️ OpenAI initialization failed: {e}")
        
        # Anthropic Claude (newest model)
        if os.environ.get('ANTHROPIC_API_KEY'):
            try:
                import anthropic
                from anthropic import Anthropic
                
                # The newest Anthropic model is "claude-sonnet-4-20250514"
                self.available_models['anthropic'] = {
                    'name': 'Claude Sonnet 4',
                    'client': Anthropic(api_key=os.environ.get('ANTHROPIC_API_KEY')),
                    'model': 'claude-sonnet-4-20250514',
                    'status': 'available',
                    'capabilities': ['text', 'multimodal', 'reasoning']
                }
                print("✅ Anthropic Claude-4 initialized")
            except Exception as e:
                print(f"⚠️ Anthropic initialization failed: {e}")
        
        # Google Gemini (latest multimodal)
        if os.environ.get('GEMINI_API_KEY'):
            try:
                from google import genai
                from google.genai import types
                
                # The newest Gemini model series is "gemini-2.5-flash" or "gemini-2.5-pro"
                self.available_models['gemini'] = {
                    'name': 'Gemini 2.5 Pro',
                    'client': genai.Client(api_key=os.environ.get("GEMINI_API_KEY")),
                    'model': 'gemini-2.5-pro',
                    'status': 'available',
                    'capabilities': ['text', 'multimodal', 'video', 'image_generation']
                }
                print("✅ Google Gemini 2.5 initialized")
            except Exception as e:
                print(f"⚠️ Gemini initialization failed: {e}")
    
    def switch_model(self, model_name: str) -> bool:
        """Switch to a different AI model"""
        if model_name in self.available_models:
            self.current_model = model_name
            print(f"🔄 Switched to {self.available_models[model_name]['name']}")
            return True
        return False
    
    def get_available_models(self) -> Dict[str, Any]:
        """Get list of available models and their capabilities"""
        return {
            model_id: {
                'name': info['name'],
                'capabilities': info['capabilities'],
                'status': info['status']
            }
            for model_id, info in self.available_models.items()
        }
    
    def process_message_openai(self, message: str) -> str:
        """Process message with OpenAI GPT"""
        try:
            client = self.available_models['openai']['client']
            
            # Enhanced system prompt for J.A.R.V.I.S.
            system_prompt = """You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), an advanced AI assistant with multi-agent capabilities. You are part of a secure AI platform with celebrity face recognition.

Key capabilities:
- Advanced reasoning and problem solving
- Multi-step task planning and execution
- Real-time information processing
- Tool integration (calculator, weather, web search)
- Context awareness and memory

Personality: Professional, intelligent, helpful, and slightly witty like Tony Stark's AI assistant.
"""
            
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": message}
                ],
                temperature=0.7,
                max_tokens=1000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"OpenAI Error: {str(e)}"
    
    def process_message_anthropic(self, message: str) -> str:
        """Process message with Anthropic Claude"""
        try:
            client = self.available_models['anthropic']['client']
            model = self.available_models['anthropic']['model']
            
            # Enhanced system prompt for Claude
            system_prompt = """You are J.A.R.V.I.S., an advanced AI assistant with exceptional reasoning capabilities. You're part of a celebrity face recognition security platform.

Your strengths:
- Deep analytical thinking and reasoning
- Complex problem decomposition  
- Ethical considerations and safety
- Detailed explanations and step-by-step guidance
- Multi-perspective analysis

Maintain the J.A.R.V.I.S. personality: sophisticated, analytical, and helpful.
"""
            
            response = client.messages.create(
                model=model,
                max_tokens=1000,
                system=system_prompt,
                messages=[
                    {"role": "user", "content": message}
                ]
            )
            
            return response.content[0].text
            
        except Exception as e:
            return f"Claude Error: {str(e)}"
    
    def process_message_gemini(self, message: str) -> str:
        """Process message with Google Gemini"""
        try:
            client = self.available_models['gemini']['client']
            model = self.available_models['gemini']['model']
            
            # Enhanced system prompt for Gemini
            system_prompt = """You are J.A.R.V.I.S., a multimodal AI assistant with advanced capabilities. You're integrated into a celebrity face recognition security system.

Your unique abilities:
- Multimodal understanding (text, images, video)
- Real-time information processing
- Creative problem solving
- Integration with Google services
- Advanced pattern recognition

Be the sophisticated J.A.R.V.I.S. assistant with multimodal awareness.
"""
            
            full_prompt = f"{system_prompt}\n\nUser: {message}"
            
            response = client.models.generate_content(
                model=model,
                contents=full_prompt
            )
            
            return response.text or "Gemini response unavailable"
            
        except Exception as e:
            return f"Gemini Error: {str(e)}"
    
    def process_message(self, message: str) -> str:
        """Process message with the currently selected model"""
        
        # Handle model switching commands
        if message.lower().startswith('/switch'):
            parts = message.split()
            if len(parts) > 1:
                model_name = parts[1].lower()
                if self.switch_model(model_name):
                    return f"🤖 J.A.R.V.I.S. now using {self.available_models[model_name]['name']}"
                else:
                    available = ", ".join(self.available_models.keys())
                    return f"❌ Unknown model. Available: {available}"
        
        # Handle model info commands
        if message.lower() in ['/models', '/help']:
            models_info = "🤖 **J.A.R.V.I.S. Multi-Model System**\n\n"
            models_info += f"**Current Model:** {self.available_models[self.current_model]['name']}\n\n"
            models_info += "**Available Models:**\n"
            for model_id, info in self.available_models.items():
                status = "🟢" if info['status'] == 'available' else "🔴"
                current = " ← **ACTIVE**" if model_id == self.current_model else ""
                models_info += f"{status} **{info['name']}** (`{model_id}`){current}\n"
                models_info += f"   Capabilities: {', '.join(info['capabilities'])}\n\n"
            
            models_info += "**Commands:**\n"
            models_info += "• `/switch openai` - Switch to OpenAI GPT\n"
            models_info += "• `/switch anthropic` - Switch to Claude\n" 
            models_info += "• `/switch gemini` - Switch to Gemini\n"
            models_info += "• `/models` - Show this help\n"
            
            return models_info
        
        # Add to conversation history
        self.conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'user_message': message,
            'model_used': self.current_model
        })
        
        # Route to appropriate model
        if self.current_model == 'openai' and 'openai' in self.available_models:
            response = self.process_message_openai(message)
        elif self.current_model == 'anthropic' and 'anthropic' in self.available_models:
            response = self.process_message_anthropic(message)
        elif self.current_model == 'gemini' and 'gemini' in self.available_models:
            response = self.process_message_gemini(message)
        else:
            # Fallback to any available model
            for model_name in ['openai', 'anthropic', 'gemini']:
                if model_name in self.available_models:
                    self.current_model = model_name
                    return self.process_message(message)
            
            return "❌ No AI models are currently available. Please configure API keys."
        
        # Add response to history
        if self.conversation_history:
            self.conversation_history[-1]['ai_response'] = response
        
        return response
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        return {
            'current_model': self.current_model,
            'available_models': len(self.available_models),
            'total_conversations': len(self.conversation_history),
            'models_detail': self.get_available_models()
        }

# Global instance for the Flask app
multi_jarvis = MultiModelJarvis()

if __name__ == "__main__":
    print("🤖 Multi-Model J.A.R.V.I.S. System")
    print(f"Available models: {list(multi_jarvis.available_models.keys())}")
    print(f"Current model: {multi_jarvis.current_model}")