import os
import json
from datetime import datetime

# Using python_openai blueprint integration - from python_openai integration
# the newest OpenAI model is "gpt-5" which was released August 7, 2025. 
# do not change this unless explicitly requested by the user
from openai import OpenAI

class JarvisAgent:
    """J.A.R.V.I.S. Multi-Agent AI Assistant System"""
    
    def __init__(self):
        self.openai_client = None
        self.conversation_history = []
        self.tools = {
            'weather': self.get_weather,
            'calculator': self.calculate,
            'time': self.get_time,
            'help': self.show_help
        }
        self._initialize_openai()
    
    def _initialize_openai(self):
        """Initialize OpenAI client with API key"""
        try:
            api_key = os.environ.get("OPENAI_API_KEY")
            if api_key:
                self.openai_client = OpenAI(api_key=api_key)
                print("J.A.R.V.I.S. OpenAI integration initialized successfully")
            else:
                print("Warning: OPENAI_API_KEY not found, running in demo mode")
        except Exception as e:
            print(f"J.A.R.V.I.S. OpenAI initialization error: {e}")
    
    def process_message(self, user_message):
        """Process user message and return intelligent response"""
        if not user_message:
            return "Please provide a message for me to process."
        
        # Store message in conversation history
        self.conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'user': user_message,
            'type': 'user_input'
        })
        
        # Check for tool commands first
        response = self._check_tool_commands(user_message)
        if response:
            return response
        
        # Use OpenAI for intelligent responses
        if self.openai_client:
            try:
                response = self._get_openai_response(user_message)
            except Exception as e:
                response = f"I'm experiencing some connectivity issues. Error: {str(e)}"
        else:
            response = self._get_fallback_response(user_message)
        
        # Store response in conversation history
        self.conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'jarvis': response,
            'type': 'ai_response'
        })
        
        return response
    
    def _check_tool_commands(self, message):
        """Check if message contains tool commands and execute them"""
        message_lower = message.lower()
        
        if 'weather' in message_lower:
            return self.get_weather()
        elif any(op in message_lower for op in ['calculate', 'math', '+', '-', '*', '/']):
            return self.calculate(message)
        elif 'time' in message_lower:
            return self.get_time()
        elif 'help' in message_lower:
            return self.show_help()
        
        return None
    
    def _get_openai_response(self, user_message):
        """Get response from OpenAI GPT model"""
        try:
            # Build conversation context
            messages = [
                {
                    "role": "system", 
                    "content": "You are J.A.R.V.I.S., an intelligent AI assistant integrated into a security platform. You are helpful, professional, and have access to various tools. Keep responses concise but informative."
                }
            ]
            
            # Add recent conversation history for context
            for entry in self.conversation_history[-5:]:  # Last 5 exchanges
                if entry['type'] == 'user_input':
                    messages.append({"role": "user", "content": entry['user']})
                elif entry['type'] == 'ai_response':
                    messages.append({"role": "assistant", "content": entry['jarvis']})
            
            # Add current message
            messages.append({"role": "user", "content": user_message})
            
            response = self.openai_client.chat.completions.create(
                model="gpt-5",  # newest OpenAI model per integration blueprint
                messages=messages,
                max_tokens=500,
                temperature=0.7
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"I encountered an error processing your request: {str(e)}"
    
    def _get_fallback_response(self, user_message):
        """Fallback responses when OpenAI is not available"""
        fallback_responses = {
            'hello': "Hello! I'm J.A.R.V.I.S., your AI assistant. I'm currently running in demo mode.",
            'how are you': "I'm functioning well, thank you for asking! How may I assist you today?",
            'what can you do': "I can help with weather information, calculations, time queries, and general assistance. Try asking me about the weather or to calculate something!",
            'default': f"I understand you said: '{user_message}'. I'm currently running in demo mode. For full functionality, please ensure the OpenAI integration is properly configured."
        }
        
        message_lower = user_message.lower()
        for key in fallback_responses:
            if key in message_lower and key != 'default':
                return fallback_responses[key]
        
        return fallback_responses['default']
    
    def get_weather(self):
        """Tool: Get weather information"""
        return "🌤️ Weather: Currently sunny, 72°F. This is a demo response - full weather integration coming soon!"
    
    def calculate(self, expression):
        """Tool: Perform safe calculations without eval()"""
        try:
            import re
            # Extract numbers and operators safely
            tokens = re.findall(r'\d+\.?\d*|[+\-*/()]', expression)
            if not tokens:
                return "🧮 Calculator: Please provide a valid mathematical expression"
            
            # Simple calculation logic without eval()
            expression_str = ''.join(tokens)
            
            # Basic validation - only allow safe characters
            safe_chars = set('0123456789+-*/.() ')
            if not all(c in safe_chars for c in expression_str):
                return "🧮 Calculator: Only basic mathematical operations are allowed"
            
            # Use ast.literal_eval for safer evaluation of simple expressions
            import ast
            import operator
            
            # Simple math operations
            ops = {
                ast.Add: operator.add,
                ast.Sub: operator.sub,
                ast.Mult: operator.mul,
                ast.Div: operator.truediv,
                ast.USub: operator.neg,
            }
            
            def safe_eval(node):
                if isinstance(node, ast.Num):
                    return node.n
                elif isinstance(node, ast.BinOp):
                    left = safe_eval(node.left)
                    right = safe_eval(node.right)
                    return ops[type(node.op)](left, right)
                elif isinstance(node, ast.UnaryOp):
                    return ops[type(node.op)](safe_eval(node.operand))
                else:
                    raise ValueError("Unsupported operation")
            
            tree = ast.parse(expression_str, mode='eval')
            result = safe_eval(tree.body)
            return f"🧮 Calculation result: {expression_str} = {result}"
            
        except Exception as e:
            return "🧮 Calculator: Please provide a valid mathematical expression (e.g., 2 + 2, 10 * 5)"
    
    def get_time(self):
        """Tool: Get current time"""
        current_time = datetime.now().strftime("%I:%M %p on %B %d, %Y")
        return f"🕐 Current time: {current_time}"
    
    def show_help(self):
        """Tool: Show available commands"""
        return """🤖 J.A.R.V.I.S. Available Commands:
        
• Ask about weather: "What's the weather?"
• Calculate: "Calculate 25 * 4" or "What's 100 / 5?"
• Get time: "What time is it?"
• General chat: Ask me anything!

I'm your intelligent assistant ready to help with various tasks."""

    def get_conversation_history(self):
        """Get the full conversation history"""
        return self.conversation_history
    
    def clear_history(self):
        """Clear conversation history"""
        self.conversation_history = []
        return "Conversation history cleared."