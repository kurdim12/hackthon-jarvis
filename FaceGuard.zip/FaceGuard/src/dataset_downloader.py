"""
Dataset downloader for the AI Security Platform
Downloads real hackathon dataset from Google Drive
"""

import gdown
import os
import pandas as pd
from pathlib import Path
import shutil

class DatasetDownloader:
    def __init__(self):
        self.dataset_path = Path("dataset")
        self.folder_id = "1J9mNED7JlylTk7xNcNtQJUYCiOr-bdAy"
        self.drive_url = f"https://drive.google.com/drive/folders/{self.folder_id}"
        
    def download_dataset(self):
        """Download the complete dataset from Google Drive"""
        try:
            print("🔄 Downloading real hackathon dataset from Google Drive...")
            
            # Create dataset directory
            self.dataset_path.mkdir(exist_ok=True)
            
            # Download the entire folder
            print(f"📥 Downloading from: {self.drive_url}")
            gdown.download_folder(
                self.drive_url,
                output=str(self.dataset_path),
                quiet=False,
                use_cookies=False
            )
            
            print("✅ Dataset download completed successfully!")
            return True
            
        except Exception as e:
            print(f"❌ Error downloading dataset: {e}")
            return False
    
    def verify_dataset(self):
        """Verify that the dataset was downloaded correctly"""
        try:
            photos_found = list(self.dataset_path.glob("**/*.jpg")) + \
                          list(self.dataset_path.glob("**/*.png")) + \
                          list(self.dataset_path.glob("**/*.jpeg"))
            
            excel_files = list(self.dataset_path.glob("**/*.xlsx")) + \
                         list(self.dataset_path.glob("**/*.xls"))
            
            print(f"📊 Found {len(photos_found)} photos in dataset")
            print(f"📊 Found {len(excel_files)} Excel files in dataset")
            
            if photos_found:
                print("✅ Photo files found:")
                for photo in photos_found[:5]:  # Show first 5
                    print(f"  • {photo.name}")
                if len(photos_found) > 5:
                    print(f"  ... and {len(photos_found) - 5} more")
            
            if excel_files:
                print("✅ Excel files found:")
                for excel in excel_files:
                    print(f"  • {excel.name}")
            
            return len(photos_found) > 0 and len(excel_files) > 0
            
        except Exception as e:
            print(f"❌ Error verifying dataset: {e}")
            return False
    
    def get_photos_path(self):
        """Get the path to downloaded photos"""
        photos = list(self.dataset_path.glob("**/*.jpg")) + \
                list(self.dataset_path.glob("**/*.png")) + \
                list(self.dataset_path.glob("**/*.jpeg"))
        return [str(p) for p in photos]
    
    def get_excel_path(self):
        """Get the path to the downloaded Excel file"""
        excel_files = list(self.dataset_path.glob("**/*.xlsx")) + \
                     list(self.dataset_path.glob("**/*.xls"))
        return str(excel_files[0]) if excel_files else None
    
    def organize_dataset(self):
        """Organize downloaded files into a proper structure"""
        try:
            # Create organized structure
            photos_dir = self.dataset_path / "photos"
            excel_dir = self.dataset_path / "excel"
            
            photos_dir.mkdir(exist_ok=True)
            excel_dir.mkdir(exist_ok=True)
            
            # Move photos to photos directory
            photos_found = list(self.dataset_path.glob("**/*.jpg")) + \
                          list(self.dataset_path.glob("**/*.png")) + \
                          list(self.dataset_path.glob("**/*.jpeg"))
            
            for photo in photos_found:
                if photo.parent != photos_dir:
                    new_path = photos_dir / photo.name
                    shutil.move(str(photo), str(new_path))
                    print(f"📁 Moved {photo.name} to photos/")
            
            # Move Excel files to excel directory
            excel_files = list(self.dataset_path.glob("**/*.xlsx")) + \
                         list(self.dataset_path.glob("**/*.xls"))
            
            for excel in excel_files:
                if excel.parent != excel_dir:
                    new_path = excel_dir / excel.name
                    shutil.move(str(excel), str(new_path))
                    print(f"📁 Moved {excel.name} to excel/")
            
            print("✅ Dataset organized successfully!")
            return True
            
        except Exception as e:
            print(f"❌ Error organizing dataset: {e}")
            return False

if __name__ == "__main__":
    downloader = DatasetDownloader()
    
    if downloader.download_dataset():
        if downloader.verify_dataset():
            downloader.organize_dataset()
            print("🎉 Real dataset is ready for use!")
        else:
            print("⚠️ Dataset verification failed")
    else:
        print("❌ Failed to download dataset")