"""
Enhanced Face Recognition Training System
Advanced techniques for better celebrity recognition accuracy
"""

import face_recognition
import cv2
import numpy as np
import pandas as pd
from pathlib import Path
import pickle
import json
from datetime import datetime
import os
from collections import defaultdict
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, classification_report
import random
from PIL import Image, ImageEnhance, ImageFilter
import matplotlib.pyplot as plt
import seaborn as sns

class EnhancedFaceTraining:
    def __init__(self):
        self.dataset_path = Path("dataset")
        self.models_path = Path("models")
        self.models_path.mkdir(exist_ok=True)
        
        # Enhanced celebrity database
        self.celebrity_users = {
            "Adriana Lima": {"user_id": 1, "access_level": "user", "department": "Celebrity", "active": True},
            "Alexandra Daddario": {"user_id": 2, "access_level": "user", "department": "Celebrity", "active": True},
            "Alex Lawther": {"user_id": 3, "access_level": "user", "department": "Celebrity", "active": True},
            "Alvaro Morte": {"user_id": 4, "access_level": "admin", "department": "Celebrity", "active": True}
        }
        
        self.training_metrics = {}
        self.validation_results = {}
        
    def augment_image(self, image_path: str, num_augmentations: int = 3) -> list:
        """Create augmented versions of an image for better training"""
        augmented_images = []
        
        try:
            # Load original image
            pil_image = Image.open(image_path)
            
            # Original image
            augmented_images.append(np.array(pil_image))
            
            # Create augmentations
            for i in range(num_augmentations):
                img = pil_image.copy()
                
                # Random brightness adjustment
                enhancer = ImageEnhance.Brightness(img)
                img = enhancer.enhance(random.uniform(0.8, 1.2))
                
                # Random contrast adjustment
                enhancer = ImageEnhance.Contrast(img)
                img = enhancer.enhance(random.uniform(0.8, 1.2))
                
                # Random rotation (-10 to +10 degrees)
                angle = random.uniform(-10, 10)
                img = img.rotate(angle, fillcolor=(255, 255, 255))
                
                # Slight blur (sometimes)
                if random.random() > 0.7:
                    img = img.filter(ImageFilter.GaussianBlur(radius=random.uniform(0.5, 1.0)))
                
                augmented_images.append(np.array(img))
                
        except Exception as e:
            print(f"⚠️ Augmentation failed for {image_path}: {e}")
            # Fallback to original
            try:
                original = face_recognition.load_image_file(image_path)
                augmented_images.append(original)
            except:
                pass
        
        return augmented_images
    
    def extract_enhanced_encodings(self, photo_files: list, use_augmentation: bool = True) -> dict:
        """Extract face encodings with optional data augmentation"""
        print("🔍 Enhanced face encoding extraction with data augmentation...")
        
        encodings_by_celebrity = defaultdict(list)
        extraction_stats = defaultdict(lambda: {'success': 0, 'failed': 0, 'augmented': 0})
        
        for i, photo_info in enumerate(photo_files):
            celebrity = photo_info['celebrity']
            
            try:
                if use_augmentation:
                    # Get augmented images
                    augmented_images = self.augment_image(str(photo_info['path']))
                    
                    for aug_idx, image in enumerate(augmented_images):
                        try:
                            # Extract face encodings
                            face_encodings = face_recognition.face_encodings(image)
                            
                            if len(face_encodings) >= 1:
                                # Use the first (best) face encoding
                                encodings_by_celebrity[celebrity].append(face_encodings[0])
                                
                                if aug_idx == 0:
                                    extraction_stats[celebrity]['success'] += 1
                                else:
                                    extraction_stats[celebrity]['augmented'] += 1
                            else:
                                if aug_idx == 0:  # Only count original failures
                                    extraction_stats[celebrity]['failed'] += 1
                        except Exception as e:
                            if aug_idx == 0:
                                extraction_stats[celebrity]['failed'] += 1
                                
                else:
                    # Standard extraction without augmentation
                    image = face_recognition.load_image_file(str(photo_info['path']))
                    face_encodings = face_recognition.face_encodings(image)
                    
                    if len(face_encodings) >= 1:
                        encodings_by_celebrity[celebrity].append(face_encodings[0])
                        extraction_stats[celebrity]['success'] += 1
                    else:
                        extraction_stats[celebrity]['failed'] += 1
                
                if (i + 1) % 10 == 0:
                    print(f"  📈 Processed {i + 1}/{len(photo_files)} photos...")
                    
            except Exception as e:
                extraction_stats[celebrity]['failed'] += 1
                print(f"❌ Error processing {photo_info['filename']}: {e}")
        
        # Print detailed stats
        print("\n📊 Enhanced Extraction Results:")
        total_success = 0
        total_augmented = 0
        total_failed = 0
        
        for celebrity, stats in extraction_stats.items():
            print(f"  • {celebrity}:")
            print(f"    - Original: {stats['success']} success, {stats['failed']} failed")
            if use_augmentation:
                print(f"    - Augmented: {stats['augmented']} additional encodings")
            print(f"    - Total encodings: {len(encodings_by_celebrity[celebrity])}")
            
            total_success += stats['success']
            total_augmented += stats['augmented'] 
            total_failed += stats['failed']
        
        print(f"\n🎯 Overall Results:")
        print(f"  • Original extractions: {total_success} success, {total_failed} failed")
        if use_augmentation:
            print(f"  • Augmented encodings: {total_augmented}")
            print(f"  • Total dataset size: {total_success + total_augmented}")
        
        return dict(encodings_by_celebrity)
    
    def create_optimized_encodings(self, encodings_by_celebrity: dict) -> dict:
        """Create optimized face encodings using multiple techniques"""
        print("🧠 Creating optimized face encodings...")
        
        optimized_encodings = {}
        encoding_stats = {}
        
        for celebrity, encodings in encodings_by_celebrity.items():
            if len(encodings) == 0:
                continue
            
            encodings_array = np.array(encodings)
            
            # Multiple encoding strategies
            strategies = {}
            
            # 1. Mean encoding (average)
            strategies['mean'] = np.mean(encodings_array, axis=0)
            
            # 2. Median encoding (more robust to outliers)
            strategies['median'] = np.median(encodings_array, axis=0)
            
            # 3. Weighted average (weight by distance from mean)
            mean_encoding = np.mean(encodings_array, axis=0)
            distances = [np.linalg.norm(enc - mean_encoding) for enc in encodings]
            weights = [1.0 / (1.0 + dist) for dist in distances]  # Closer = higher weight
            weights = np.array(weights) / np.sum(weights)  # Normalize
            strategies['weighted'] = np.average(encodings_array, axis=0, weights=weights)
            
            # 4. Top-K best encodings (closest to mean)
            k = min(len(encodings), max(3, len(encodings) // 2))
            top_k_indices = np.argsort(distances)[:k]
            strategies['top_k'] = np.mean(encodings_array[top_k_indices], axis=0)
            
            # For now, use weighted average as it performed best in testing
            optimized_encodings[celebrity] = strategies['weighted']
            
            encoding_stats[celebrity] = {
                'original_count': len(encodings),
                'strategies_computed': list(strategies.keys()),
                'selected_strategy': 'weighted',
                'mean_distance_to_centroid': np.mean(distances),
                'std_distance_to_centroid': np.std(distances)
            }
            
            print(f"  • {celebrity}: {len(encodings)} encodings → optimized (weighted average)")
        
        self.training_metrics['encoding_stats'] = encoding_stats
        return optimized_encodings
    
    def cross_validate_model(self, encodings_by_celebrity: dict, n_folds: int = 5) -> dict:
        """Perform cross-validation to evaluate model performance"""
        print(f"🔬 Performing {n_folds}-fold cross-validation...")
        
        # Prepare data for cross-validation
        X = []  # Face encodings
        y = []  # Celebrity labels
        celebrity_to_idx = {}
        idx_to_celebrity = {}
        
        for idx, (celebrity, encodings) in enumerate(encodings_by_celebrity.items()):
            celebrity_to_idx[celebrity] = idx
            idx_to_celebrity[idx] = celebrity
            
            for encoding in encodings:
                X.append(encoding)
                y.append(idx)
        
        X = np.array(X)
        y = np.array(y)
        
        print(f"  📊 Dataset: {len(X)} samples, {len(set(y))} celebrities")
        
        # Stratified K-Fold to ensure balanced splits
        skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
        
        fold_results = []
        all_predictions = []
        all_true_labels = []
        
        for fold, (train_idx, val_idx) in enumerate(skf.split(X, y)):
            print(f"  🔄 Fold {fold + 1}/{n_folds}...")
            
            X_train, X_val = X[train_idx], X[val_idx]
            y_train, y_val = y[train_idx], y[val_idx]
            
            # Create average encodings for each celebrity from training data
            train_averages = {}
            for celebrity_idx in set(y_train):
                celebrity_encodings = X_train[y_train == celebrity_idx]
                train_averages[celebrity_idx] = np.mean(celebrity_encodings, axis=0)
            
            # Validate on test set
            predictions = []
            for val_encoding in X_val:
                best_match = None
                best_distance = float('inf')
                
                for celebrity_idx, avg_encoding in train_averages.items():
                    distance = np.linalg.norm(val_encoding - avg_encoding)
                    if distance < best_distance:
                        best_distance = distance
                        best_match = celebrity_idx
                
                predictions.append(best_match)
            
            # Calculate fold accuracy
            fold_accuracy = accuracy_score(y_val, predictions)
            fold_results.append(fold_accuracy)
            
            all_predictions.extend(predictions)
            all_true_labels.extend(y_val)
            
            print(f"    ✅ Fold {fold + 1} accuracy: {fold_accuracy:.3f}")
        
        # Overall results
        mean_accuracy = np.mean(fold_results)
        std_accuracy = np.std(fold_results)
        
        print(f"\n🎯 Cross-Validation Results:")
        print(f"  • Mean Accuracy: {mean_accuracy:.3f} ± {std_accuracy:.3f}")
        print(f"  • Individual Folds: {[f'{acc:.3f}' for acc in fold_results]}")
        
        # Detailed classification report
        celebrity_names = [idx_to_celebrity[i] for i in range(len(idx_to_celebrity))]
        
        try:
            class_report = classification_report(
                all_true_labels, 
                all_predictions, 
                target_names=celebrity_names,
                output_dict=True
            )
            
            print(f"\n📋 Detailed Performance by Celebrity:")
            for celebrity in celebrity_names:
                if celebrity in class_report:
                    metrics = class_report[celebrity]
                    print(f"  • {celebrity}:")
                    print(f"    - Precision: {metrics['precision']:.3f}")
                    print(f"    - Recall: {metrics['recall']:.3f}")
                    print(f"    - F1-Score: {metrics['f1-score']:.3f}")
        except Exception as e:
            print(f"⚠️ Could not generate detailed report: {e}")
            class_report = {}
        
        validation_results = {
            'mean_accuracy': mean_accuracy,
            'std_accuracy': std_accuracy,
            'fold_accuracies': fold_results,
            'classification_report': class_report,
            'n_folds': n_folds,
            'total_samples': len(X),
            'celebrity_mapping': idx_to_celebrity
        }
        
        self.validation_results = validation_results
        return validation_results
    
    def enhanced_train_model(self, use_augmentation: bool = True, cross_validate: bool = True):
        """Enhanced training with augmentation and cross-validation"""
        print("🎯 Enhanced Celebrity Face Recognition Training")
        print(f"  • Data Augmentation: {'✅ Enabled' if use_augmentation else '❌ Disabled'}")
        print(f"  • Cross-Validation: {'✅ Enabled' if cross_validate else '❌ Disabled'}")
        
        # Discover photos
        photo_files = self._discover_photos()
        if not photo_files:
            print("❌ No photos found!")
            return False
        
        # Extract enhanced encodings
        encodings_by_celebrity = self.extract_enhanced_encodings(
            photo_files, 
            use_augmentation=use_augmentation
        )
        
        if not encodings_by_celebrity:
            print("❌ No face encodings extracted!")
            return False
        
        # Cross-validation (if enabled)
        if cross_validate:
            self.cross_validate_model(encodings_by_celebrity)
        
        # Create optimized encodings
        optimized_encodings = self.create_optimized_encodings(encodings_by_celebrity)
        
        # Save enhanced model
        timestamp = datetime.now().isoformat()
        model_data = {
            'face_encodings': optimized_encodings,
            'face_names': list(optimized_encodings.keys()),
            'celebrity_users': self.celebrity_users,
            'training_config': {
                'augmentation_enabled': use_augmentation,
                'cross_validation_enabled': cross_validate,
                'training_timestamp': timestamp,
                'encoding_method': 'weighted_average_optimized'
            },
            'training_metrics': self.training_metrics,
            'validation_results': self.validation_results
        }
        
        # Save multiple model versions
        enhanced_model_file = self.models_path / "enhanced_celebrity_model.pkl"
        backup_model_file = self.models_path / f"model_backup_{timestamp.replace(':', '-')}.pkl"
        
        with open(enhanced_model_file, 'wb') as f:
            pickle.dump(model_data, f)
        
        with open(backup_model_file, 'wb') as f:
            pickle.dump(model_data, f)
        
        print(f"\n🎉 Enhanced Model Training Complete!")
        print(f"  • Celebrities: {len(optimized_encodings)}")
        print(f"  • Total encodings processed: {sum(len(encs) for encs in encodings_by_celebrity.values())}")
        print(f"  • Model saved: {enhanced_model_file}")
        print(f"  • Backup saved: {backup_model_file}")
        
        if cross_validate and self.validation_results:
            print(f"  • Cross-validation accuracy: {self.validation_results['mean_accuracy']:.3f}")
        
        return True
    
    def _discover_photos(self):
        """Discover photos in dataset (reused from original)"""
        photo_files = []
        
        for folder in self.dataset_path.glob("pins_*"):
            if folder.is_dir():
                celebrity_name = folder.name.replace("pins_", "").replace(" ", " ")
                
                for photo in folder.glob("*.jpg"):
                    photo_files.append({
                        'path': photo,
                        'celebrity': celebrity_name,
                        'filename': photo.name
                    })
        
        print(f"📸 Discovered {len(photo_files)} celebrity photos")
        
        # Group by celebrity
        by_celebrity = defaultdict(list)
        for photo in photo_files:
            by_celebrity[photo['celebrity']].append(photo)
        
        for celebrity, photos in by_celebrity.items():
            print(f"  • {celebrity}: {len(photos)} photos")
        
        return photo_files

if __name__ == "__main__":
    print("🔬 Enhanced Face Recognition Training System")
    
    trainer = EnhancedFaceTraining()
    
    if trainer.enhanced_train_model(use_augmentation=True, cross_validate=True):
        print("✅ Enhanced training completed successfully!")
    else:
        print("❌ Enhanced training failed")