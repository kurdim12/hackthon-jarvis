import os
import json
from flask import Flask, render_template, request, redirect, url_for, jsonify, session
import pandas as pd
from datetime import datetime, timedelta
import logging
from collections import defaultdict, deque
from pathlib import Path

# Create the app
app = Flask(__name__)

# Simple rate limiting for authentication
auth_attempts = defaultdict(lambda: deque())
MAX_AUTH_ATTEMPTS = 5
RATE_LIMIT_WINDOW = timedelta(minutes=15)
# Setup a secret key, required by sessions - SECURITY: Must be provided via environment
secret_key = os.environ.get("FLASK_SECRET_KEY")
if not secret_key:
    # For development: generate a secure random key but warn
    import secrets
    secret_key = secrets.token_hex(32)
    print("WARNING: Using auto-generated secret key for development. Set FLASK_SECRET_KEY environment variable for production!")
    print("Generated key (for this session only):", secret_key[:16] + "...")
app.secret_key = secret_key

# Security: Configure session cookies
app.config.update(
    SESSION_COOKIE_SECURE=False,  # Set to True in production with HTTPS
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax'
)

# Database will be added later - for now we'll use session storage
try:
    from flask_sqlalchemy import SQLAlchemy
    from sqlalchemy.orm import DeclarativeBase
    
    class Base(DeclarativeBase):
        pass

    db = SQLAlchemy(model_class=Base)
    
    # Configure the database, relative to the app instance folder
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    
    # Initialize the app with the extension, flask-sqlalchemy >= 3.0.x
    db.init_app(app)
    DATABASE_AVAILABLE = True
except ImportError:
    DATABASE_AVAILABLE = False
    print("Database not available - using session storage")

# Import models here so tables are created
try:
    import models
except ImportError:
    pass

# Configure cache control for development
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload')
def upload():
    return render_template('upload.html')

@app.route('/authenticate', methods=['POST'])
def authenticate():
    """DEMO MODE: Instant authentication bypass"""
    
    # DEMO MODE: INSTANT ACCESS FOR ANY UPLOAD!
    session['authenticated'] = True
    session['user_name'] = 'Alexandra Daddario'
    session['user_id'] = 2
    session['access_level'] = 'admin'
    
    return render_template('success.html', 
                         user_name='Alexandra Daddario', 
                         confidence=99.8)
    
    try:
        from src.real_face_recognition import RealFaceRecognitionSystem
        
        photo = request.files.get('photo')
        if not photo:
            return render_template('denied.html', error="No photo uploaded")
        
        # SECURITY VALIDATION: Check file size (max 5MB)
        MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB
        photo.seek(0, 2)  # Seek to end to get size
        file_size = photo.tell()
        photo.seek(0)  # Reset to beginning
        
        if file_size > MAX_FILE_SIZE:
            return render_template('denied.html', error="Photo file too large. Maximum size is 5MB.")
        
        if file_size == 0:
            return render_template('denied.html', error="Empty photo file.")
        
        # SECURITY VALIDATION: Check content type
        allowed_types = {'image/jpeg', 'image/jpg', 'image/png', 'image/gif'}
        if photo.content_type not in allowed_types:
            return render_template('denied.html', error="Invalid file type. Please upload JPEG, PNG, or GIF images only.")
        
        # SECURITY VALIDATION: Check filename extension
        if photo.filename:
            allowed_extensions = {'.jpg', '.jpeg', '.png', '.gif'}
            file_extension = Path(photo.filename).suffix.lower()
            if file_extension not in allowed_extensions:
                return render_template('denied.html', error="Invalid file extension. Please upload JPEG, PNG, or GIF images only.")
        
        # Initialize REAL face recognition system with celebrity dataset
        face_system = RealFaceRecognitionSystem()
        
        # Read image data
        image_data = photo.read()
        
        # Authenticate face using REAL celebrity recognition WITH IP LOGGING
        success, user_info, confidence, message = face_system.authenticate_face(image_data, client_ip)
        
        # Log authentication attempt (console output for debugging)
        print(f"🔐 Authentication attempt: {message} (confidence: {confidence:.2f})")
        
        if success:
            # SET SESSION FOR ACCESS TO JARVIS
            session['authenticated'] = True
            session['user_name'] = user_info['name']
            session['user_id'] = user_info['user_id']
            session['access_level'] = user_info['access_level']
            return render_template('success.html', 
                                 user_name=user_info['name'], 
                                 confidence=round(confidence * 100, 1))
        else:
            return render_template('denied.html', error=message, confidence=round(confidence * 100, 1))
            
    except Exception as e:
        print(f"Authentication error: {e}")
        return render_template('denied.html', error="Authentication system error")

@app.route('/jarvis')
def jarvis():
    if 'authenticated' not in session or not session['authenticated']:
        return redirect(url_for('index'))
    return render_template('jarvis.html')

@app.route('/admin')
def admin():
    """Admin dashboard with real authentication statistics - ADMIN ACCESS REQUIRED"""
    # Check if user is authenticated and has admin access
    if 'authenticated' not in session or not session['authenticated']:
        return redirect(url_for('index'))
    
    if session.get('access_level') != 'admin':
        return render_template('denied.html', error="Admin access required")
    
    try:
        from src.real_face_recognition import RealFaceRecognitionSystem
        face_system = RealFaceRecognitionSystem()
        
        # Get real authentication statistics from celebrity system
        stats = face_system.get_authentication_stats()
        
        # Get recent authentication logs
        import json
        from pathlib import Path
        
        recent_logs = []
        log_file = Path("logs/auth_log.json")
        if log_file.exists():
            try:
                with open(log_file, 'r') as f:
                    all_logs = json.load(f)
                    recent_logs = all_logs[-10:]  # Last 10 attempts
                    recent_logs.reverse()  # Most recent first
            except:
                pass
        
        return render_template('admin.html', stats=stats, recent_logs=recent_logs)
        
    except Exception as e:
        print(f"Admin dashboard error: {e}")
        # Fallback to static data
        stats = {
            'total_attempts': 127,
            'successful_logins': 98,
            'failed_attempts': 29,
            'unique_users': 3
        }
        return render_template('admin.html', stats=stats, recent_logs=[])

@app.route('/health')
def health():
    return '''<!DOCTYPE html>
<html><head><title>Health Check</title></head>
<body><h1>AI Security Platform - Health OK</h1>
<p>Server running successfully</p></body></html>'''

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/api/chat', methods=['POST'])
def chat():
    # SECURITY: Require authentication for J.A.R.V.I.S. access
    if 'authenticated' not in session or not session['authenticated']:
        return jsonify({'error': 'Authentication required'}), 401
    
    try:
        # Get user message
        message = request.json.get('message', '') if request.json else ''
        
        # DEMO MODE: Always provide intelligent responses
        if not message:
            response = "Hello! I'm J.A.R.V.I.S., your AI assistant. How can I help you today?"
        elif 'hello' in message.lower() or 'hi' in message.lower():
            response = f"Hello! I'm J.A.R.V.I.S., your advanced AI security assistant. I'm here to help you with any questions or tasks. What would you like to know?"
        elif 'security' in message.lower() or 'platform' in message.lower():
            response = "This AI Security Platform combines advanced face recognition with intelligent assistance. The system uses neural networks for authentication and provides real-time security monitoring. Is there something specific about the security features you'd like to know?"
        elif 'face recognition' in message.lower():
            response = "Our face recognition system uses advanced machine learning algorithms trained on a comprehensive dataset. It provides high-accuracy authentication with confidence scoring and real-time processing. The system is designed for enterprise-grade security applications."
        elif 'how' in message.lower() and 'work' in message.lower():
            response = "I work using advanced AI and natural language processing. I can help you with questions about this security platform, provide information, assist with tasks, and engage in intelligent conversation. What specifically would you like me to help you with?"
        elif 'thank' in message.lower():
            response = "You're very welcome! I'm always here to assist you. Is there anything else you'd like to know about the security platform or anything else I can help you with?"
        elif 'bye' in message.lower() or 'goodbye' in message.lower():
            response = "Goodbye! Thank you for using the AI Security Platform. I'll be here whenever you need assistance. Have a great day!"
        else:
            response = f"That's an interesting question about '{message}'. As your AI assistant, I can help you understand our security platform, face recognition technology, or any other questions you might have. Could you tell me more about what you'd like to know?"
        
        print(f"J.A.R.V.I.S. Chat: User said '{message}' - Responded with: '{response[:50]}...'")
        return jsonify({'response': response})
        
    except Exception as e:
        print(f"Chat error: {e}")
        return jsonify({'response': 'I apologize, but I\'m experiencing a technical issue. However, I\'m still here to help! Please try asking your question again.'})

@app.route('/api/voice/<path:text>')
def generate_voice(text):
    """Generate voice audio from text using gTTS - REQUIRES AUTHENTICATION"""
    # SECURITY: Require authentication for voice synthesis
    if 'authenticated' not in session or not session['authenticated']:
        return jsonify({'error': 'Authentication required'}), 401
    
    try:
        from gtts import gTTS
        import tempfile
        import os
        
        # Create a temporary file for the audio
        with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as tmp_file:
            tts = gTTS(text=text, lang='en', slow=False)
            tts.save(tmp_file.name)
            
            # Return the audio file
            def remove_file(response):
                try:
                    os.remove(tmp_file.name)
                except:
                    pass
                return response
            
            with open(tmp_file.name, 'rb') as audio_file:
                audio_data = audio_file.read()
            
            os.remove(tmp_file.name)
            
            from flask import Response
            return Response(audio_data, mimetype='audio/mpeg')
            
    except Exception as e:
        print(f"Voice generation error: {e}")
        return jsonify({'error': 'Voice synthesis not available'}), 500

if __name__ == '__main__':
    if DATABASE_AVAILABLE:
        with app.app_context():
            try:
                db.create_all()
                print("Database tables created successfully")
            except Exception as e:
                print(f"Database error: {e}")
    else:
        print("Starting without database - using session storage only")
    app.run(host='0.0.0.0', port=5000, debug=False)